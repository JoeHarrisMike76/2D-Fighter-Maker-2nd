VIRUSCAN WARNING!! 
FALSE POSITIVE OR NOT, NEVER CONFIRMED.
UPLOADED JUST FOR PRESERVATION
USE IT AT YOUR OWN RISK.

	This is the updated Final version of 2D Fighter Maker 2nd with all the functions available for your dream fighting game to create. 
	
	Unfortunately due to its age and an english translated hacked version, newer antivirus flagged the editor as infected possibly a false positive or not. We used this tool for many years without any problems even today at modern Windows. 

	We also wished to find a very clean and updated version but what we only found is the old unpatched one with some functions missing from the final version.

	It's now up to you to decide on using this software or not. Give it a test on a virtual machine or a sandbox.

	If you're still afraid of the software's unclean status, use the clean but an old unpatched version of the editor.

AGAIN THIS VERSION IS UPLOADED FOR PRESERVATION AND FOR THOSE WHO ALEADY KNEW THIS SOFTWARE AND AWARE OF IT'S ISSUES.